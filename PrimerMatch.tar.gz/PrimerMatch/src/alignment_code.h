/**************************************************************************
 * This code is part of the supporting infrastructure for ATA Mapper. 
 * Copyright (C) 2002,2003,2004 Applera Corporation. All rights reserved.
 * Author: Nathan Edwards
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received (LICENSE.txt) a copy of the GNU General Public 
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *************************************************************************/


#ifndef _IBPEP_alignment_code_h
#define _IBPEP_alignment_code_h

# define alignment_codes 13
enum alignment_code {
  alignment_none=0,
  alignment_equal=1,
  alignment_wildcard_equal=2,
  alignment_substitution=3,
  alignment_insertion=4,
  alignment_deletion=5,
  alignment_constraint_violation=6,
  alignment_end = 7,
  alignment_substitution_1=8,
  alignment_substitution_2=9,
  alignment_substitution_3=10,
  alignment_insertion_3=11,
  alignment_deletion_3=12
};

enum alignment_masks {
  alignment_mask_none = 1,
  alignment_mask_equal = 2,
  alignment_mask_wildcard_equal = 4,
  alignment_mask_substitution = 8,
  alignment_mask_insertion = 16,
  alignment_mask_deletion = 32,
  alignment_mask_constraint_violation = 64,
  alignment_mask_alignment_end = 128,
  alignment_mask_substitution_1 = 256,
  alignment_mask_substitution_2 = 512,
  alignment_mask_substitution_3 = 1024,
  alignment_mask_insertion_3 = 2048,
  alignment_mask_deletion_3 = 4096
};

#endif
